package com.johnson.KenyaCountiesDatasetApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KenyaCountiesDatasetApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(KenyaCountiesDatasetApiApplication.class, args);
	}

}

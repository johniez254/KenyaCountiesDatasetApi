package com.johnson.KenyaCountiesDatasetApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KenyaCountiesDatasetApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
